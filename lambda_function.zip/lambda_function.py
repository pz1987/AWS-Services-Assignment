import boto3
region = 'us-east-1'
instances = ['i-07a26a190d6526de4','i-01270f59e848f07e7','i-0b9c0ca987ce03231']
ec2 = boto3.client('ec2', region_name=region)
def lambda_handler(event, context):
#   ec2.stop_instances(InstanceIds=instances)
    ec2.start_instances(InstanceIds=instances)
    print('stopped your instances: ' + str(instances))